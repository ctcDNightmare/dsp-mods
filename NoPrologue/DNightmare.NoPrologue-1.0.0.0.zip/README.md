## DNightmare's NoPrologue

Tired of clicking those extra buttons when starting a new game to skip the prologue?
This simple yet effective mod will do that for you.